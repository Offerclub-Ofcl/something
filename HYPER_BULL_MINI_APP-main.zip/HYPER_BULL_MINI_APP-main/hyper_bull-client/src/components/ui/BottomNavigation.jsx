import { Link, useLocation } from "react-router-dom";
import withdraw_icon from "../../assets/icons/withdraw_active_icon.png";
import withdraw_unactive_icon from "../../assets/icons/withdraw_unactive_icon.png";

const BottomNavigation = () => {
    const getUrl = useLocation()?.pathname;

    return (
        <div className="fixed bottom-0 z-50 w-full bg-[#262626] px-4 py-4 flex justify-between items-center">

            <Link to={'/'} className="flex flex-col justify-center items-center gap-1">
                <div className={`flex justify-center items-center flex-col ${getUrl === '/' && 'text-black bg-white p-1 bg-opacity-50 rounded-full'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                    </svg>

                </div>
                <p className="font-roboto text-xs">Home</p>
            </Link>

            <Link to={'/leaderboard'} className="flex flex-col justify-center items-center gap-1">
                <div className={`flex justify-center items-center flex-col ${getUrl === '/leaderboard' && 'text-black bg-white p-1 bg-opacity-50 rounded-full'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 0 1 3 3h-15a3 3 0 0 1 3-3m9 0v-3.375c0-.621-.503-1.125-1.125-1.125h-.871M7.5 18.75v-3.375c0-.621.504-1.125 1.125-1.125h.872m5.007 0H9.497m5.007 0a7.454 7.454 0 0 1-.982-3.172M9.497 14.25a7.454 7.454 0 0 0 .981-3.172M5.25 4.236c-.982.143-1.954.317-2.916.52A6.003 6.003 0 0 0 7.73 9.728M5.25 4.236V4.5c0 2.108.966 3.99 2.48 5.228M5.25 4.236V2.721C7.456 2.41 9.71 2.25 12 2.25c2.291 0 4.545.16 6.75.47v1.516M7.73 9.728a6.726 6.726 0 0 0 2.748 1.35m8.272-6.842V4.5c0 2.108-.966 3.99-2.48 5.228m2.48-5.492a46.32 46.32 0 0 1 2.916.52 6.003 6.003 0 0 1-5.395 4.972m0 0a6.726 6.726 0 0 1-2.749 1.35m0 0a6.772 6.772 0 0 1-3.044 0" />
                    </svg>
                </div>
                <p className="font-roboto text-xs">Leaderboard</p>
            </Link>

            <Link to={'/refer'} className="flex flex-col justify-center items-center gap-1">
                <div className={`flex justify-center items-center flex-col ${getUrl === '/refer' && 'text-black bg-white p-1 bg-opacity-50 rounded-full'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" />
                    </svg>
                </div>
                <p className="font-roboto text-xs">Refer</p>
            </Link>

            <Link to={'/airdrop'} className="flex flex-col justify-center items-center gap-1">
                <div className={`flex justify-center items-center flex-col ${getUrl === '/airdrop' && 'text-black bg-white p-1 bg-opacity-50 rounded-full'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5M9 11.25v1.5M12 9v3.75m3-6v6" />
                    </svg>
                </div>
                <p className="font-roboto text-xs">Airdrop</p>
            </Link>
        </div>
    );
};

export default BottomNavigation;
