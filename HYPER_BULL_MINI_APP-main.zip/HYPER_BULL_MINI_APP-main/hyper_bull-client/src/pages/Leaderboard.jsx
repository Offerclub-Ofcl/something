import Leaderborard from "../components/template/Home/Leaderborard";
import { TonConnectButton } from "@tonconnect/ui-react";
import bull_image from "../assets/images/bull-attacking.jpg";

const LeaderboardPage = () => {

    return (
        <div className="bg-black min-h-screen">
            <div className="p-3">
                <div className="flex justify-between items-center">
                    <p className="capitalize text-xl font-medium text-white">Hyper bull</p>
                    <TonConnectButton />
                </div>
                <img src={bull_image} className="h-40 mx-auto" alt="" />
                <p className="text-center text-white text-2xl font-bold">Telegram Wall Of Fame</p>
            </div>

            {/* <Profile_temp /> */}
            <Leaderborard />
        </div>
    );
};

export default LeaderboardPage;