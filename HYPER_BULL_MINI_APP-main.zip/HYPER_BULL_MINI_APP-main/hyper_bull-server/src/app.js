const express = require('express');
const cors = require('cors');
const MainRoutes = require('./routes');
require('dotenv').config()
const app = express();
app.use(express.json());
app.use(cors({
    origin: [
        "http://localhost:5173",
        "http://localhost:5174",
        "https://sft-protocal-client.vercel.app",
        "https://hyper-bull-client.vercel.app"
    ],
    credentials: true,
}));

app.use("/api/v1", MainRoutes);

app.get("/manifest", async (req, res) => {
    res.send({
        "url": "https://hyper.bull",
        "name": "Hyper bull",
        "iconUrl": "https://i.ibb.co.com/sjv5Rfr/IMG-20240923-WA0003.jpg"
    });
})

app.use((req, res, next) => {
    res.status(404).send({
        msg: 'no routes in this location...',
        statusCode: 200,
        data: []
    })
})

app.use((err, req, res, next) => {
    res.status(500).send({
        stack: process.env.MODE === 'DEV' ? err.message : undefined,
        msg: process.env.MODE !== 'DEV' ? 'something went wrong' : undefined,
        statusCode: 200,
        data: []
    })
})

app.get('/', async (req, res) => {
    res.send('Server is okay')
})

module.exports = {
    app
}